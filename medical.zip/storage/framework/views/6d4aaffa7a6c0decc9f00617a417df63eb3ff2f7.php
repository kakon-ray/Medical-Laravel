
<?php $__env->startSection('title','Admin'); ?>
<?php $__env->startSection('content'); ?>


  <main>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3">
          <!-- Sidebar -->
  <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
    <div class="position-sticky">
      <div class="list-group list-group-flush mx-3 mt-4">
        <a
          href="#"
          class="list-group-item list-group-item-action py-2 ripple"
          aria-current="true"
        >
          <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Main dashboard</span>
        </a>
        <a href="#" class="list-group-item list-group-item-action py-2 ripple active">
          <i class="fas fa-chart-area fa-fw me-3"></i><span>Appointment Request</span>
        </a>
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-lock fa-fw me-3"></i><span>Password</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-chart-line fa-fw me-3"></i><span>Analytics</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple">
          <i class="fas fa-chart-pie fa-fw me-3"></i><span>SEO</span>
        </a>
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-chart-bar fa-fw me-3"></i><span>Orders</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-globe fa-fw me-3"></i><span>International</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-building fa-fw me-3"></i><span>Partners</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-calendar fa-fw me-3"></i><span>Calendar</span></a
        >
        <a href="#" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-users fa-fw me-3"></i><span>Users</span></a
        >
        <a type="button" id="arthilogout" class="list-group-item list-group-item-action py-2 ripple"
          ><i class="fas fa-money-bill fa-fw me-3"></i><span>Logout</span></a
        >
      </div>
    </div>
  </nav>
        </div>
        <div class="col-lg-9">
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam, reprehenderit hic iusto exercitationem dolor est vitae numquam minus commodi, sunt tenetur doloremque? Rerum labore quisquam necessitatibus similique exercitationem impedit eveniet dignissimos ullam ipsa voluptas, adipisci ab praesentium possimus aspernatur perferendis? Rerum eos accusamus libero aperiam velit. Blanditiis aperiam provident quis. Sunt quod, facere deserunt, commodi aliquid non aspernatur iste quia illum molestias consequatur ipsum placeat fuga. Numquam earum pariatur vero sapiente cumque, voluptate quod ad reiciendis sint sunt dolor rem amet distinctio quasi repellat, deserunt doloribus cum similique? Ad dolore, fugit odit totam odio saepe cum impedit? Vel facere laborum quod delectus autem eos totam tenetur excepturi similique eius aliquid provident vitae voluptates quasi, dolorum repellendus ducimus quidem sit commodi beatae numquam? Laudantium, quibusdam ipsam similique tenetur eius consectetur saepe quos veritatis, voluptates fugit repudiandae. Nesciunt aspernatur delectus consectetur similique nulla veritatis magni quas non quam eaque, amet totam quaerat quo cumque eum velit excepturi assumenda. Iste minus aspernatur repellat ipsa similique labore saepe dignissimos nihil soluta qui adipisci quisquam quaerat, enim sapiente nobis beatae perspiciatis rerum recusandae corrupti excepturi, nostrum doloribus in! Natus excepturi culpa, accusamus voluptas voluptatibus nisi repellat debitis voluptates vel iste tempora necessitatibus rerum blanditiis non.</p>
        </div>
      </div>
    </div>
  </main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\versity\working\medical\medical\resources\views/admin/admin.blade.php ENDPATH**/ ?>