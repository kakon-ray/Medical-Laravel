<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Cookie;

class SiteController extends Controller
{
    function home(){

        return view('home');
   }

    function clinic(){

        return view('clinic');
   }

    function appointment(){

        return view('appointment');
   }

    function contact(){

        return view('contact');
   }

    function admin(){

        return view('admin.admin');
   }

   function Registation(){
    return view('registation');
   }

   function Login(){
    return view('login');
   }


//    admin registation
   function admin_registaion(Request $request){
    $admin_name = $request->input('admin_name');
    $admin_email = $request->input('admin_email');
    $admin_password = $request->input('admin_password');

        // Validate password strength start
        $uppercase = preg_match('@[A-Z]@', $admin_password);
        $lowercase = preg_match('@[a-z]@', $admin_password);
        $number    = preg_match('@[0-9]@', $admin_password);
        $specialChars = preg_match('@[^\w]@', $admin_password);

        if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($admin_password) < 8){
            return "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.";
        }
           // Validate password strength end

           $admin_password = md5($admin_password);

           $already_have_email = Admin::where('email', $admin_email)->count();
           $name = Admin::where('name', $admin_name)->count();


           if($name){
            return "Alreday have this Name";
            }
    
        
        if($already_have_email){
            return "Already have this Email";
        }

        if(filter_var($admin_email, FILTER_VALIDATE_EMAIL) == false){
            return "Please Enter Valid Email";
        }

        $responce = Admin::insert([
            'name' => $admin_name,
            'email' => $admin_email,
            'password' => $admin_password,
          
        ]);
   
        if($responce == 1){
            return 1;
        }


   }

   function admin_login(Request $request){
    $admin_email_login = $request->input('admin_email_login');
    $admin_password_login = $request->input('admin_password_login');

    $admin_password_login = md5($admin_password_login);
    
    $responce = Admin::where('email', $admin_email_login)->where('password', $admin_password_login)->count();
    if($responce == 1){
        cookie::queue('admin',$admin_email_login, 1296000 );
         return 1;
        
     }
    


   }

   function logout(){
    cookie::queue(cookie::forget('admin'));
    return 1;
   }




}
